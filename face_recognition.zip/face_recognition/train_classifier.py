import os
import cv2
import joblib
import numpy as np
from sklearn.svm import SVC
from sklearn.model_selection import train_test_split, cross_val_score
from sklearn.metrics import (confusion_matrix, classification_report, accuracy_score, 
                             precision_score, recall_score, f1_score, roc_curve, auc)
import matplotlib.pyplot as plt
import seaborn as sns
import face_recognition
from sklearn.preprocessing import label_binarize
import matplotlib.cm as cm


def create_embeddings(image_folder):
    embeddings = []
    labels = []
    for person_name in os.listdir(image_folder):
        person_path = os.path.join(image_folder, person_name)
        if os.path.isdir(person_path):
            for image_name in os.listdir(person_path):
                image_path = os.path.join(person_path, image_name)
                img = cv2.imread(image_path)
                
                if img is None:
                    print(f"Error reading image: {image_path}")
                    continue

                # Convert the image to RGB as face_recognition works with RGB images
                img_rgb = cv2.cvtColor(img, cv2.COLOR_BGR2RGB)
                
                # Detect faces and compute embeddings
                face_locations = face_recognition.face_locations(img_rgb)
                face_encodings = face_recognition.face_encodings(img_rgb, face_locations)
                
                if not face_encodings:
                    print(f"No faces detected in {image_path}")
                    continue
                
                for face_encoding in face_encodings:
                    embeddings.append(face_encoding)
                    labels.append(person_name)
    
    embeddings = np.array(embeddings)
    labels = np.array(labels)
    
    if embeddings.size == 0:
        raise ValueError("No embeddings were extracted. Check the face detection and image reading process.")
    
    print("Embeddings shape:", embeddings.shape)
    print("Labels shape:", labels.shape)
    print("Sample embedding:", embeddings[0] if embeddings.shape[0] > 0 else "No embeddings found")
    
    return embeddings, labels

def plot_confusion_matrix(cm, classes, output_folder):
    plt.figure(figsize=(10, 7))
    sns.heatmap(cm, annot=True, fmt='d', cmap='Blues', xticklabels=classes, yticklabels=classes)
    plt.xlabel('Predicted Label')
    plt.ylabel('True Label')
    plt.title('Confusion Matrix')
    plt.savefig(os.path.join(output_folder, 'confusion_matrix.png'))
    plt.close()


def plot_roc_curve(y_test, y_score, class_names, output_folder):
    y_test_bin = label_binarize(y_test, classes=class_names)
    n_classes = len(class_names)

    # Compute ROC curve and AUC for each class
    fpr = dict()
    tpr = dict()
    roc_auc = dict()

    for i in range(n_classes):
        fpr[i], tpr[i], _ = roc_curve(y_test_bin[:, i], y_score[:, i])
        roc_auc[i] = auc(fpr[i], tpr[i])

    # Compute micro-average ROC curve and AUC
    fpr["micro"], tpr["micro"], _ = roc_curve(y_test_bin.ravel(), y_score.ravel())
    roc_auc["micro"] = auc(fpr["micro"], tpr["micro"])

    # Plot ROC curves
    plt.figure()
    plt.plot(fpr["micro"], tpr["micro"], color='deeppink', lw=2, label=f'micro-average ROC curve (area = {roc_auc["micro"]:.2f})')

    # Use colormap from matplotlib.pyplot
    colors = plt.get_cmap('tab20', n_classes)
    for i in range(n_classes):
        plt.plot(fpr[i], tpr[i], color=colors(i / n_classes), lw=2, label=f'class {class_names[i]} (area = {roc_auc[i]:.2f})')

    plt.xlabel('False Positive Rate')
    plt.ylabel('True Positive Rate')
    plt.title('Receiver Operating Characteristic')
    # Position the legend outside the plot
    plt.legend(loc='center left', bbox_to_anchor=(1, 0.5), fontsize='small')
    plt.tight_layout(rect=[0, 0, 0.85, 1])  # Adjust layout to make space for the legend
    plt.savefig(os.path.join(output_folder, 'roc_curve.png'))
    plt.close()


def main():
    # Hardcoded path to the training images
    image_folder = 'train/'
    output_folder = '.'

    # Create embeddings and labels from training images
    embeddings, labels = create_embeddings(image_folder)
    
    # Split data into training and testing sets
    X_train, X_test, y_train, y_test = train_test_split(embeddings, labels, test_size=0.2, random_state=42)

    # Experiment with different SVM parameters to reduce overfitting
    model = SVC(probability=True, C=0.1)

    # Cross-validation with the SVM model
    cv_scores = cross_val_score(model, X_train, y_train, cv=5)
    print("Cross-validation scores:", cv_scores)
    print("Mean cross-validation score:", np.mean(cv_scores))

    # Train the SVM model
    model.fit(X_train, y_train)

    # Save the trained model
    if not os.path.exists(output_folder):
        os.makedirs(output_folder)
    joblib.dump(model, os.path.join(output_folder, 'face_classifier.joblib'))
    print("Model trained and saved as face_classifier.joblib")

    # Evaluate the model
    y_pred = model.predict(X_test)
    y_proba = model.predict_proba(X_test) # Use predict_proba for ROC curve

    # Confusion Matrix
    cm = confusion_matrix(y_test, y_pred, labels=model.classes_)
    plot_confusion_matrix(cm, model.classes_, output_folder)

    # Classification Report
    report = classification_report(y_test, y_pred, target_names=model.classes_)
    print("Classification Report:\n", report)

    # Accuracy, Precision, Recall, F1 Score
    accuracy = accuracy_score(y_test, y_pred)
    precision = precision_score(y_test, y_pred, average='weighted')
    recall = recall_score(y_test, y_pred, average='weighted')
    f1 = f1_score(y_test, y_pred, average='weighted')

    print(f"Accuracy: {accuracy:.2f}")
    print(f"Precision: {precision:.2f}")
    print(f"Recall: {recall:.2f}")
    print(f"F1 Score: {f1:.2f}")

    # ROC Curve and AUC
    plot_roc_curve(y_test, y_proba, model.classes_, output_folder)

if __name__ == "__main__":
    main()
